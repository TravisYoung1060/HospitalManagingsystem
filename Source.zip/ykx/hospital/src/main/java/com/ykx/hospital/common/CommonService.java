package com.ykx.hospital.common;

public class CommonService {
    public static String del_message_success="删除成功";
    public static String del_message_error="删除失败";
    public static String upd_message_success="更新成功";
    public static String upd_message_error="更新失败";
    public static String add_message_success="添加成功";
    public static String add_message_error="添加失败";
    public static String add_message_error2="已存在";
}
